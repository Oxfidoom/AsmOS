extends Button


func _ready():
	pass


func _on_Button4_pressed():
	OS.shell_open("https://sociabuzz.com/foringham/tribe")
