extends Label

var task3 = 0

func _ready():
	pass

func _on_butask3_pressed():
	task3 += 5
	text = str(task3)
	if task3 == 100:
		queue_free()

