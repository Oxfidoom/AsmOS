extends Label

var dialog4 = 1
func _ready():
	pass

func _on_dialtimer4_timeout():
	$lanjut4.queue_free()

func _on_lanjut4_pressed():
	dialog4 += 1
	if dialog4 == 1:
		text = "kamu : ini dia nih..."
	elif dialog4 == 2:
		text = "kamu : udah dingin tapi gak papa lahh.."
	elif dialog4 == 3:
		text = "kamu : masih kelihatan enak juga kok"
	elif dialog4 == 4:
		text = "kamu : waktunya makan"
	elif dialog4 == 5:
		queue_free()
		get_node("../background").hide()
		

