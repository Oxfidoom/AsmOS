extends Label

var dialog = 1

func _ready():
	pass

func _on_dialtimer_timeout():
	$lanjut1.queue_free()

func _on_lanjut1_pressed():
	dialog += 1
	if dialog == 1:
		text = "kamu : asu....bangun sore lagi njing!!...mana udah janji mau ambilin jemuran.."
	elif dialog == 2:
		text = "kamu : tai lah..."
	elif dialog == 3:
		text = "kamu : semoga aja tuh orang gak marah..."
	elif dialog == 4:
		text = "kamu : lagi pula diakan orang baru disini, mana berani mau marah..."
	elif dialog == 5:
		text = "kamu : makan dulu aja lah...mumpung belum hujan hehe..."
	elif dialog == 6:
		text = "kamu : kebetulan tadi malem beli bakso..."
	elif dialog == 7:
		queue_free()
		get_node("../background").hide()

