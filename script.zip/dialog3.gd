extends Label

var dialog3 = 1
func _ready():
	pass

func _on_dialtimer3_timeout():
	$lanjut3.queue_free()

func _on_lanjut3_pressed():
	dialog3 += 1
	if dialog3 == 1:
		text = "kamu : ahirnya selesai juga"
	elif dialog3 == 2:
		text = "kamu : tetangga anjing emang, minta aja marah marah"
	elif dialog3 == 3:
		text = "kamu : mana gak makasih lagi,... emang tai"
	elif dialog3 == 4:
		text = "kamu : dah ah,... mending makan"
	elif dialog3 == 5:
		queue_free()
		get_node("../background").hide()
		
