extends Label

var dialog6 = 1
func _ready():
	pass

func _on_dialtimer6_timeout():
	$lanjut6.queue_free()

func _on_lanjut6_pressed():
	dialog6 += 1
	if dialog6 == 1:
		text = "kamu : makan udah..."
	elif dialog6 == 2:
		text = "kamu : mandi udah..."
	elif dialog6 == 3:
		text = "kamu : waktunya apa?"
	elif dialog6 == 4:
		text = "kamu : waktunya tidur"
	elif dialog6 == 5:
		queue_free()
		get_node("../background").hide()
		
