extends Label

var dialog8 = 1
func _ready():
	pass

func _on_dialtimer8_timeout():
	$lanjut8.queue_free()

func _on_lanjut8_pressed():
	dialog8 += 1
	if dialog8 == 1:
		text = "kamu : oh iya lupa buang sampah"
	elif dialog8 == 2:
		queue_free()
		get_node("../background").hide()
