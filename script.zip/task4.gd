extends Label

var task4 = 0

func _ready():
	pass

func _on_butask4_pressed():
	task4 += 1
	text = str(task4)
	if task4 == 10:
		queue_free()

