extends Label


func _ready():
	pass
func _physics_process(_delta):
	if Input.is_action_pressed("restart"):
		get_tree().change_scene("res://start.tscn")
	elif Input.is_action_pressed("quit"):
		get_tree().quit()
