extends Label

var task2 = 0

func _ready():
	pass

func _on_butask2_pressed():
	task2 += 5
	text = str(task2)
	if task2 == 100:
		queue_free()
