extends Label

var dialog5 = 1
func _ready():
	pass

func _on_dialtimer5_timeout():
	$lanjut5.queue_free()

func _on_lanjut5_pressed():
	dialog5 += 1
	if dialog5 == 1:
		text = "kamu : hah kenyang juga..."
	elif dialog5 == 2:
		text = "kamu : mandi dulu dah"
	elif dialog5 == 3:
		text = "kamu : badan udah bau banget gini"
	elif dialog5 == 4:
		queue_free()
		get_node("../background").hide()
		

