extends Label

var task1 = 0

func _ready():
	pass

func _on_butask1_pressed():
	task1 += 5
	text = str(task1)
	if task1 == 100:
		queue_free()
