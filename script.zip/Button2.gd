extends Button


func _ready():
	pass


func _on_Button2_pressed():
	OS.shell_open("https://www.youtube.com/@Flowrtg")
