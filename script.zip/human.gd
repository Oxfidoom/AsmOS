extends KinematicBody

var control = false
var gravitasi = Vector3(0,0,0)
var gerak = true
var gerak2 = true
var gerak3 = false

var ind = true
var ind2 = false
var ind3 = false
var ind4 = false
var ind5 = false
var ind6 = false
var ind7 = false
var ind8 = false
var ind9 = false
var ind10 = false
var ind11 = false
var ind12 = false
var ind13 = false

var set = 0
var set2 = 0
var set3 = 0
var set5 = 0

var task1 = 0
var task2 = 0
var task3 = 0
var task4 = 0

var dialog1 = 1
var dialog2 = 1
var dialog3 = 1
var dialog4 = 1
var dialog5 = 1
var dialog6 = 1
var dialog7 = 1
func _ready():
	$bird.play()
	
func _physics_process(_delta):
	if Input.is_action_pressed("W") and control == true:
		translate(Vector3(0,0,-0.07))
	elif Input.is_action_pressed("D") and control == true:
		rotate_y(-0.04)
	elif Input.is_action_pressed("A") and control == true:
		rotate_y(0.04)
	elif Input.is_action_pressed("S") and control == true:
		translate(Vector3(0,0,0.07))
	
	if task1 == 100 and task2 == 100 and task3 == 100:
		$Control/dialog3.show()
		$Control/background.show()
		control = false
		$timerD.start()
		$Camera.environment.background_color = Color(0,0,0)
		$Camera.environment.ambient_light_color = Color(144,0,0)
		get_node("../humanoid2").show()
		ind4 = true
	if not is_on_floor():
		gravitasi.y -= 50
	else:
		gravitasi.y = -0.1
	gravitasi = move_and_slide(gravitasi, Vector3.UP)

func _on_lanjut1_pressed():
	dialog1 += 1
	if dialog1 == 7:
		control = true

func _on_area1_body_entered(body):
	if body.name == "human":
		$jumpscare.play()
		control = false
		$timerB.start()
		$timerA.start()
		$Control/dialog2.show()
		$Control/background.show()
		while gerak:
			get_node("../humanoid").translate(Vector3(-2,0,0))
			yield(get_tree(), "idle_frame")

func _on_lanjut2_pressed():
	dialog2 += 1
	if dialog2 == 7:
		control = true
		$timerC.start()
		while gerak2:
			get_node("../humanoid").translate(Vector3(2,0,0))
			yield(get_tree(), "idle_frame")

func _on_lanjut3_pressed():
	dialog3 += 1
	if dialog3 == 5:
		control = true
		$Control/dialog3.hide()
		$Control/background.hide()
		task1 = 0
		get_node("../humanoid2").hide()
		$Camera.environment.background_color = Color("ffe661")
		$Camera.environment.ambient_light_color = Color("fff9c7")
func _on_timerA_timeout():
	$jumpscare.queue_free()
	get_node("../area1").queue_free()
	$timerA.queue_free()

func _on_timerB_timeout():
	gerak = false

func _on_timerC_timeout():
	gerak2 = false
	while true:
			get_node("../humanoid").translate(Vector3(0,-3,0))
			yield(get_tree(), "idle_frame")

func _on_butask1_pressed():
	task1 += 5
	$panen.play()
	$timerAa.start()
	if task1 == 100:
		$Control/task1.hide()
		$Control/task1/butask1.hide()
		get_node("../panen").queue_free()

func _on_panen_body_entered(body):
	if body.name == "human":
		$Control/task1.show()

func _on_panen_body_exited(body):
	if body.name == "human":
		$Control/task1.hide()
		
		
func _on_butask2_pressed():
	task2 += 5
	$panen.play()
	$timerAa.start()
	if task2 == 100:
		$Control/task2.hide()
		get_node("../panen2").queue_free()

func _on_panen2_body_entered(body):
	if body.name == "human":
		$Control/task2.show()

func _on_panen2_body_exited(body):
	if body.name == "human":
		$Control/task2.hide()
		
		
func _on_butask3_pressed():
	task3 += 5
	$panen.play()
	$timerAa.start()
	if task3 == 100:
		$Control/task3.hide()
		get_node("../panen3").queue_free()

func _on_panen3_body_entered(body):
	if body.name == "human":
		$Control/task3.show()

func _on_panen3_body_exited(body):
	if body.name == "human":
		$Control/task3.hide()

func _on_timerD_timeout():
	get_node("../area2").translate(Vector3(0,0,0))
	ind = false






func _on_area2_body_entered(body):
	if body.name == "human" and ind4 == true:
		$Control/ambil.show()


func _on_lanjut4_pressed():
	control = false
	dialog4 += 1
	if dialog4 == 5:
		$Control/dialog4.hide()
		$Control/background.hide()
		control = true
		ind2 = true


func _on_ambil_pressed():
	$bakso.show()
	$Control/ambil.hide()
	$Control/dialog4.show()
	$Control/background.show()
	get_node("../area2").translate(Vector3(0,-10,0))
	control = false
	
func _on_area4_body_entered(body):
	if body.name == "human" and ind2 == true:
		$Control/task4.show()
		


func _on_butask4_pressed():
	task4 += 1
	$eat.play()
	$timerG.start()
	if task4 == 10:
		$Control/background.show()
		$bakso.hide()
		ind2 = false
		$Control/dialog5.show()
		control =false


func _on_lanjut5_pressed():
	dialog5 += 1
	if dialog5 == 4:
		$Control/background.hide()
		ind3 = true
		control = true
		$Control/background.hide()


func _on_area5_body_entered(body):
	if body.name == "human" and ind3 == true:
		$transisi.show()
		$transisi/transisi.play("transisi")
		$timerF.start()
		$time.play()
		$timerH.start()
		set2 = 2

func _on_timerF_timeout():
	$transisi.hide()
	ind3 = false
	if set2 == 2:
		$Camera.environment.background_color = Color("000014")
		$Camera.environment.ambient_light_color = Color("080041")
	dialog3 = 1
	get_node("../DirectionalLight").show()
	get_node("../DirectionalLight2").show()
	get_node("../DirectionalLight3").show()
	get_node("../DirectionalLight4").show()
	ind5 = true
	ind8 = true


func _on_timerG_timeout():
	$eat.stop()


func _on_timerH_timeout():
	$time.stop()


func _on_timerAa_timeout():
	$panen.stop()


func _on_area6_body_entered(body):
	if body.name == "human" and ind5 == true:
		$Control/dialog6.show()
		$Control/background.show()
		control =false
		get_node("../humanoid4").show()

func _on_lanjut6_pressed():
	dialog6 += 1
	if dialog6 == 5:
		$Control/dialog6.hide()
		$Control/background.hide()
		ind5 = false
		control =  true
		ind6 = true
		get_node("../area6").translate(Vector3(0,-20,0))
		ind10 = true


func _on_area7_body_entered(body):
	if body.name == "human" and ind6 == true:
		$Control/dialog7.show()
		$Control/background.show()
		control = false
		dialog6 = 0
		ind9 = true


func _on_lanjut7_pressed():
	dialog7 += 1
	if dialog7 == 2 and ind9 == true:
		control =true
		$Control/dialog7.hide()
		$Control/background.hide()
		ind6 =false
		ind8 = true


func _on_trash_body_entered(body):
	if body.name == "human" and ind8 == true:
		$Control/ambil2.show()


func _on_ambil2_pressed():
	$Control/ambil2.hide()
	get_node("../trash").hide()
	$trash.show()
	ind7 = true
	ind8 = false
	get_node("../trash").translate(Vector3(0,-20,0))

func _on_trash_body_exited(body):
	$Control/ambil2.hide()
	


func _on_area8_body_entered(body):
	if body.name == "human" and ind7 == true:
		$Control/ambil3.show()


func _on_ambil3_pressed():
	$trash.hide()
	get_node("../trash2").show()
	ind7 = false
	$Control/ambil3.hide()
	ind8 = false
	

func _on_area9_body_entered(body):
	if body.name == "human" and ind10 == true:
	   set = 1
	if set == 1:
		get_node("../humanoid3").show()
		get_node("../DirectionalLight4").light_color = Color("fff9c7")
		get_node("../humanoid4").hide()

func _on_area10_body_entered(body):
	if body.name == "human" and ind10 == true:
		set2 = 1
	if set2 == 1:
		get_node("../humanoid2").show()
		ind11 = true


func _on_area11_body_entered(body):
	if body.name == "human" and ind11 == true:
		set3 = 1
	if set3 == 1:
		set2 = 0
		get_node("../humanoid2").hide()
		ind12 = true


func _on_area12_body_entered(body):
	if body.name == "human" and ind12 == true:
		$Control/ambil4.show()


func _on_ambil4_pressed():
	$transisi2.show()
	control = false
	$timerBb.start()
	$timerCc.start()
	get_node("../area12").translate(Vector3(0,-20,0))
	


func _on_area12_body_exited(body):
	if body.name == "human" and ind12 == true:
		$Control/ambil4.hide()


func _on_timerBb_timeout():
	$transisi2.hide()


func _on_timerCc_timeout():
	$police.play()
	$timerDd.start()


func _on_timerDd_timeout():
	$police.stop()
	control =true
	get_node("../humanoid5").show()
	get_node("../humanoid5").translation = Vector3(0, 0.08, 5.51)
	get_node("../humanoid3").translation = Vector3(0, -20, 5.51)
	get_node("../area10").translate(Vector3(0,-20,0))
	ind13 = true
	


func _on_area13_body_entered(body):
	if body.name == "human" and ind13 == true:
		$Control/ambil5.show()


func _on_ambil5_pressed():
	get_tree().change_scene("res://end.tscn")


func _on_area13_body_exited(body):
	if body.name == "human" and ind13 == true:
		$Control/ambil5.hide()
