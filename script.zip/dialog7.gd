extends Label

var dialog7 = 1
func _ready():
	pass

func _on_dialtimer7_timeout():
	$lanjut7.queue_free()

func _on_lanjut7_pressed():
	dialog7 += 1
	if dialog7 == 1:
		text = "kamu : oh iya lupa buang sampah"
	elif dialog7 == 2:
		queue_free()
		get_node("../background").hide()
