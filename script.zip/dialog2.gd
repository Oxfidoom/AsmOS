extends Label

var dialog2 = 1
func _ready():
	pass

func _on_dialtimer2_timeout():
	$lanjut2.queue_free()

func _on_lanjut2_pressed():
	dialog2 += 1
	if dialog2 == 1:
		text = "tetangga : ehh...babi..gimana sih tolol!!"
	elif dialog2 == 2:
		text = "tetangga : katanya mau beresin jemuran gw!?"
	elif dialog2 == 3:
		text = "kamu : baru bangun bang"
	elif dialog2 == 4:
		text = "tetangga : bangsat lu...udah sore gini baru bangun...emang bangsat lu anjing!!"
	elif dialog2 == 5:
		text = "kamu : iya bang maaf...pelan pelan aja kan bisa"
	elif dialog2 == 6:
		text = "tetangga : taiii....taii..cepetan anjing..itu dah mendung bangsat...!!"
	elif dialog2 == 7:
		queue_free()
		get_node("../background").hide()
		
